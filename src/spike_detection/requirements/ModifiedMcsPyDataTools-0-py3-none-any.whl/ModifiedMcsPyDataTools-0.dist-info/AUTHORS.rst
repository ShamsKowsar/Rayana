=======
Authors
=======

Alphabetical list of contributors to the McsPyDataTools toolbox:

* Janko Dietzsch <dietzsch@multichannelsystems.com>
* Florian Helmhold <helmhold@multichannelsystems.com>
* Hans Loeffler <loeffler@multichannelsystems.com>
* Armin Walter <walter@multichannelsystems.com>
* Ole Wenzel <wenzel@multichannelsystems.com>

The McsPyDataTools toolbox is maintained by Armin Walter (Multi Channel Systems MCS GmbH) <walter@multichannelsystems.com>.