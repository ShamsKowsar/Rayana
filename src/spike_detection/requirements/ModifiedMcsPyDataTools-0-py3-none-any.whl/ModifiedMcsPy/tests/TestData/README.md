Test file archive
=================

The content of the accompanying test file archive for the McsPyDataTools package contains 
the raw data files that are used by the unit tests. The content of this archive must be 
copied to this folder **...\McsPy\tests\TestData\** in order to be used by the unit tests. The test file archive can be downloaded at https://download.multichannelsystems.com/download_data/software/multi-channel-datamanager/McsPyDataTools-TestDataFiles.zip.
